"""
ETL Pipeline Logging Functions
==============================
"""

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, current_timestamp, lit
from pyspark.sql.types import (
    StructType, StructField, StringType, 
    LongType, TimestampType
)
from datetime import datetime
import uuid


def log_pipeline_start(batch_day, source_table, target_table, operation,
                       pipeline_name, source_layer, target_layer, job_id_str):
    """
    Log pipeline start
    
    Args:
        batch_day (str): Batch day (YYYYMMDD)
        source_table (str): Source table name
        target_table (str): Target table name
        operation (str): Operation type (INSERT, DELETE+INSERT, etc.)
        pipeline_name (str): Pipeline name (e.g., "landing_to_bronze")
        source_layer (str): Source layer (e.g., "landing")
        target_layer (str): Target layer (e.g., "bronze")
        job_id_str (str): Job ID string
    
    Returns:
        tuple: (log_id, start_time)
    """
    
    # Get or create spark session
    spark = SparkSession.builder.getOrCreate()
    
    log_id = str(uuid.uuid4())
    
    log_data = [(
        log_id, batch_day, pipeline_name, source_layer, target_layer,
        source_table, target_table, datetime.now(), None, "RUNNING",
        operation, None, None, None, None, job_id_str, datetime.now()
    )]
    
    log_schema = StructType([
        StructField("log_id", StringType(), False),
        StructField("batch_day", StringType(), False),
        StructField("pipeline_name", StringType(), False),
        StructField("source_layer", StringType(), False),
        StructField("target_layer", StringType(), False),
        StructField("source_table", StringType(), False),
        StructField("target_table", StringType(), False),
        StructField("start_time", TimestampType(), False),
        StructField("end_time", TimestampType(), True),
        StructField("status", StringType(), False),
        StructField("operation", StringType(), False),
        StructField("rows_read", LongType(), True),
        StructField("rows_written", LongType(), True),
        StructField("rows_rejected", LongType(), True),
        StructField("error_message", StringType(), True),
        StructField("job_id", StringType(), True),
        StructField("created_timestamp", TimestampType(), False)
    ])
    
    df_log = spark.createDataFrame(log_data, log_schema)
    df_log.write.format("delta").mode("append").saveAsTable("lh_metadata.log_table_loads")
    
    print(f"  📝 Started logging with log_id: {log_id}")
    return log_id, datetime.now()


def log_pipeline_end(log_id, batch_day, source_table, target_table,
                     status, operation, rows_read, rows_written,
                     pipeline_name, source_layer, target_layer, job_id_str,
                     rows_rejected=0, error_message=None, start_time=None):
    """
    Log pipeline end
    
    Args:
        log_id (str): Log ID from log_pipeline_start
        batch_day (str): Batch day (YYYYMMDD)
        source_table (str): Source table name
        target_table (str): Target table name
        status (str): Status (SUCCESS, FAILED, WARNING)
        operation (str): Operation type
        rows_read (int): Rows read
        rows_written (int): Rows written
        pipeline_name (str): Pipeline name
        source_layer (str): Source layer
        target_layer (str): Target layer
        job_id_str (str): Job ID string
        rows_rejected (int): Rows rejected (default: 0)
        error_message (str): Error message (default: None)
        start_time (datetime): Start time (default: None)
    """
    
    # Get or create spark session
    spark = SparkSession.builder.getOrCreate()
    
    if start_time is None:
        start_time = datetime.now()
    
    log_data = [(
        log_id, batch_day, pipeline_name, source_layer, target_layer,
        source_table, target_table, start_time, datetime.now(), status,
        operation, rows_read, rows_written, rows_rejected, error_message,
        job_id_str, datetime.now()
    )]
    
    log_schema = StructType([
        StructField("log_id", StringType(), False),
        StructField("batch_day", StringType(), False),
        StructField("pipeline_name", StringType(), False),
        StructField("source_layer", StringType(), False),
        StructField("target_layer", StringType(), False),
        StructField("source_table", StringType(), False),
        StructField("target_table", StringType(), False),
        StructField("start_time", TimestampType(), False),
        StructField("end_time", TimestampType(), True),
        StructField("status", StringType(), False),
        StructField("operation", StringType(), False),
        StructField("rows_read", LongType(), True),
        StructField("rows_written", LongType(), True),
        StructField("rows_rejected", LongType(), True),
        StructField("error_message", StringType(), True),
        StructField("job_id", StringType(), True),
        StructField("created_timestamp", TimestampType(), False)
    ])
    
    df_log = spark.createDataFrame(log_data, log_schema)
    df_log.write.format("delta").mode("append").saveAsTable("lh_metadata.log_table_loads")
    
    status_emoji = "✅" if status == "SUCCESS" else "❌" if status == "FAILED" else "⚠️"
    print(f"  {status_emoji} Logged: {status}")


def create_rejection_table_if_not_exists():
    """Create rejection table if it doesn't exist"""
    
    # Get or create spark session
    spark = SparkSession.builder.getOrCreate()
    
    rejection_schema = StructType([
        StructField("rejection_id", StringType(), False),
        StructField("job_id", StringType(), False),
        StructField("batch_day", StringType(), False),
        StructField("source_table", StringType(), False),
        StructField("target_table", StringType(), False),
        StructField("source_row_hash", StringType(), False),
        StructField("rejection_reason", StringType(), False),
        StructField("failed_column", StringType(), True),
        StructField("failed_value", StringType(), True),
        StructField("expected_type", StringType(), True),
        StructField("row_data", StringType(), True),
        StructField("rejection_timestamp", TimestampType(), False)
    ])
    
    try:
        spark.table("lh_metadata.rejection_log")
        print("  ✓ Rejection log table exists")
    except:
        print("  Creating rejection log table...")
        df_empty = spark.createDataFrame([], rejection_schema)
        df_empty.write.format("delta").mode("overwrite") \
            .saveAsTable("lh_metadata.rejection_log")
        print("  ✓ Created rejection log table")


def log_rejected_rows(rejected_df, source_table, target_table, batch_day, job_id_str):
    """
    Log rejected rows to rejection table
    
    Args:
        rejected_df: DataFrame with rejected rows
        source_table (str): Source table name
        target_table (str): Target table name
        batch_day (str): Batch day (YYYYMMDD)
        job_id_str (str): Job ID string
    """
    
    if rejected_df.count() == 0:
        return
    
    # Prepare rejection records
    rejection_df = rejected_df.select(
        lit(str(uuid.uuid4())).alias("rejection_id"),
        lit(job_id_str).alias("job_id"),
        lit(batch_day).alias("batch_day"),
        lit(source_table).alias("source_table"),
        lit(target_table).alias("target_table"),
        col("_source_row_hash").alias("source_row_hash"),
        col("_rejection_reason").alias("rejection_reason"),
        col("_failed_column").alias("failed_column"),
        col("_failed_value").alias("failed_value"),
        col("_expected_type").alias("expected_type"),
        col("_row_data_json").alias("row_data"),
        current_timestamp().alias("rejection_timestamp")
    )
    
    # Append to rejection log
    rejection_df.write.format("delta").mode("append") \
        .saveAsTable("lh_metadata.rejection_log")
    
    print(f"  📋 Logged {rejected_df.count()} rejected rows to lh_metadata.rejection_log")
