"""
Adastra ETL Library for Microsoft Fabric
=========================================
ETL logging functions for pipeline execution tracking

Usage:
    import adastra_etl as etl
    
    log_id, start_time = etl.log_pipeline_start(...)
    etl.log_pipeline_end(...)
"""

__version__ = "1.0.0"
__author__ = "Adastra Data Engineering Team"

from .logging import (
    log_pipeline_start,
    log_pipeline_end,
    create_rejection_table_if_not_exists,
    log_rejected_rows
)

__all__ = [
    'log_pipeline_start',
    'log_pipeline_end',
    'create_rejection_table_if_not_exists',
    'log_rejected_rows'
]

print("="*80)
print(f"Adastra ETL Library v{__version__}")
print("Available functions: log_pipeline_start, log_pipeline_end,")
print("                     create_rejection_table_if_not_exists, log_rejected_rows")
print("="*80)
